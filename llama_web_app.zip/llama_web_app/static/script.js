async function sendPrompt() {
    const promptInput = document.getElementById("prompt");
    const prompt = promptInput.value.trim();
    const sendBtn = document.getElementById("send-btn");
    const loading = document.getElementById("loading");
    const chatHistory = document.getElementById("chat-history");
    
    if (!prompt) {
        alert("Por favor escribe un mensaje");
        return;
    }
    
    // Agregar mensaje del usuario al historial
    addMessage("Usuario", prompt, "user-message");
    
    // Limpiar input y deshabilitar botón
    promptInput.value = "";
    sendBtn.disabled = true;
    loading.style.display = "block";
    
    try {
        const res = await fetch("/generate", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ prompt })
        });
        
        const data = await res.json();
        
        if (data.error) {
            addMessage("Error", data.error, "assistant-message");
        } else {
            addMessage("Llama 3", data.response, "assistant-message");
        }
    } catch (error) {
        addMessage("Error", "No se pudo conectar con el servidor: " + error.message, "assistant-message");
    } finally {
        loading.style.display = "none";
        sendBtn.disabled = false;
        promptInput.focus();
    }
}

function addMessage(sender, text, className) {
    const chatHistory = document.getElementById("chat-history");
    const messageDiv = document.createElement("div");
    messageDiv.className = `message ${className}`;
    messageDiv.innerHTML = `<strong>${sender}:</strong><p>${text}</p>`;
    chatHistory.appendChild(messageDiv);
    
    // Scroll automático al último mensaje
    chatHistory.scrollTop = chatHistory.scrollHeight;
}

// Permitir enviar con Enter (Shift+Enter para nueva línea)
document.getElementById("prompt").addEventListener("keypress", function(e) {
    if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        sendPrompt();
    }
});
