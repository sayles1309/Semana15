from flask import Flask, render_template, request, jsonify
from transformers import AutoTokenizer, AutoModelForCausalLM
import torch
import os
from dotenv import load_dotenv

# Cargar variables de entorno
load_dotenv()

app = Flask(__name__)

# Configuración del modelo
model_id = "meta-llama/Meta-Llama-3-8B-Instruct"

print("🔄 Cargando modelo Llama 3... Esto puede tomar varios minutos...")

# Autenticación con Hugging Face
hf_token = os.getenv("HF_TOKEN")

# Cargar tokenizer y modelo
tokenizer = AutoTokenizer.from_pretrained(
    model_id, 
    token=hf_token
)
model = AutoModelForCausalLM.from_pretrained(
    model_id, 
    device_map="auto",
    token=hf_token,
    torch_dtype=torch.float16  # Usar float16 para ahorrar memoria
)

print("✅ Modelo cargado exitosamente!")

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/generate", methods=["POST"])
def generate():
    try:
        prompt = request.json.get("prompt", "")
        
        if not prompt:
            return jsonify({"error": "No se proporcionó un prompt"}), 400
        
        # Formatear el prompt para Llama 3 Instruct
        formatted_prompt = f"<|begin_of_text|><|start_header_id|>user<|end_header_id|>\n\n{prompt}<|eot_id|><|start_header_id|>assistant<|end_header_id|>\n\n"
        
        # Tokenizar
        inputs = tokenizer(formatted_prompt, return_tensors="pt").to(model.device)
        
        # Generar respuesta
        with torch.no_grad():
            outputs = model.generate(
                **inputs, 
                max_new_tokens=300,
                temperature=0.7,
                top_p=0.9,
                do_sample=True
            )
        
        # Decodificar
        full_response = tokenizer.decode(outputs[0], skip_special_tokens=True)
        
        # Extraer solo la respuesta del asistente
        response = full_response.split("assistant")[-1].strip()
        
        return jsonify({"response": response})
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(debug=False, host="0.0.0.0", port=5000)